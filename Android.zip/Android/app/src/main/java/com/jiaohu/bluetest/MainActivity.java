package com.jiaohu.bluetest;


import android.view.MotionEvent;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.UUID;
//import com.jiaohu.bluetest.R;
import com.jiaohu.bluetest.R;

import android.content.Context;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.util.Log;
import android.view.Menu;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import java.io.IOException;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.FormBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
//import com.alibaba.fastjson.JSONObject;

//import cn.finalteam.okhttpfinal.HttpRequest;
//import cn.finalteam.okhttpfinal.JsonHttpRequestCallback;
//import cn.finalteam.okhttpfinal.RequestParams;

import android.support.v7.app.ActionBar;

public class MainActivity extends Activity {

//    Context context;
//    CirqueProgressControlView ccv=new CirqueProgressControlView(context,this);
    CirqueProgressControlView ccv;
    private Toast toast;
    //定义组件
    TextView statusLabel;
    private Button btnConnect,btnSend,btnSendone,btnQuit;
    private EditText etSend;
    private TextView etReceived,etPredict;
    private Button ok,okone;
    private ImageView imgone;
    //private EditText username;

    //device var
    private BluetoothAdapter mBluetoothAdapter = null;

    private BluetoothSocket btSocket = null;

    private OutputStream outStream = null;

    private InputStream inStream = null;


    //这条是蓝牙串口通用的UUID，不要更改
    private static final UUID MY_UUID =
            UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");

    private static String address = "98:D3:31:F6:42:BD"; // <==要连接的目标蓝牙设备MAC地址


    private ReceiveThread rThread=null;  //数据接收线程

    //接收到的字符串
    String strR;
    String ReceiveData="";

    MyHandler handler;


    public void Init()
    {
        statusLabel=(TextView)this.findViewById(R.id.textView41);
        btnConnect=(Button)this.findViewById(R.id.button_active);
//        btnSend=(Button)this.findViewById(R.id.button2);
//        btnQuit=(Button)this.findViewById(R.id.button3);
//        btnSendone=(Button)this.findViewById(R.id.button5);
        ok = (Button)this.findViewById(R.id.button_rcm);
        imgone=(ImageView)this.findViewById(R.id.imageView61);
//        okone=(Button)this.findViewById(R.id.button6);

        etReceived=(TextView)this.findViewById(R.id.textView4);
        etPredict=(TextView) this.findViewById(R.id.textView40);


        ccv = (CirqueProgressControlView) findViewById(R.id.ccv);
        ccv.setProgressRange(0, 50);//可以在xml中指定，也可以在代码中设置——设置范围
        //        ccv.setIsAnim(false);//这个方法必须在setProgress之前执行
        ccv.setProgress(27);  //添加默认数据--注:不能超出范围
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //etSend=findViewById(R.id.editText1);
        //etPredict=findViewById(R.id.editText3);

        //username = findViewById(R.id.editText3);
        //首先调用初始化函数
//        ActionBar actionBar = getSupportActionBar();
//        if (actionBar != null){
//            actionBar.hide();
//        }
        Init();
        InitBluetooth();


        handler=new MyHandler();


        btnConnect.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //判断蓝牙是否打开
                if(!mBluetoothAdapter.isEnabled())
                {
                    mBluetoothAdapter.enable();
                }
                mBluetoothAdapter.startDiscovery();

                //创建连接
                new ConnectTask().execute(address);

            }
        });


//        btnQuit.setOnClickListener(new View.OnClickListener() {
//
//            @Override
//            public void onClick(View v) {
//                // TODO Auto-generated method stub
//
//                if(btSocket!=null)
//                {
//                    try {
//                        btSocket.close();
//                        btSocket=null;
//                        if(rThread!=null)
//                        {
//                            rThread.join();
//                        }
//                        statusLabel.setText("当前连接已断开");
////						etReceived.setText("");
//                    } catch (IOException e) {
//
//                        e.printStackTrace();
//                    } catch (InterruptedException e) {
//
//                        e.printStackTrace();
//                    }
//                }
//
//
//
//            }
//        });
//        btnSendone.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                String temp = ReceiveData;
//                String url = "http://192.168.43.170:80/register";//替换成自己的服务器地址
//                SendMessage(url,temp);
//            }
//        });
//        btnSend.setOnClickListener(new View.OnClickListener() {
//
//            @Override
//            public void onClick(View v) {
//                // TODO Auto-generated method stub
//                new SendInfoTask().execute(etSend.getText().toString()+"X");
//                new Handler().postDelayed(new Runnable() {
//                    @Override
//                    public void run() {
//                        SendMessage("http://123.207.114.109:8080/register",ReceiveData);
//
//                        /**
//                         * 延时执行的代码
//
//                         */
//
//                    }
//                },3000); // 延时3秒
//
//                //
//
//
//
//            }
//        });


//        ccv.setOnTouchListener(new View.OnTouchListener(){
//
//            @Override
//            public void onTouch(View v,MotionEvent event)
//            {
//
//            }
//
//        });

        ccv.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {

                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:                          //当在圆圈上按下触点
                        return false;
                    case MotionEvent.ACTION_MOVE:               //当触点在移动
                        return false;
                    case MotionEvent.ACTION_UP:                 //触点松开
//                        Toast.makeText(MainActivity.this, ccv.mCurrentProgress, Toast.LENGTH_SHORT).show();
                        new SendInfoTask().execute(ccv.mCurrentProgress+"X");
                        new Handler().postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                SendMessage("http://123.207.114.109:8080/register",ReceiveData);

                                /**
                                 * 延时执行的代码

                                 */
                            }
                        },3000); // 延时3秒

                         return false;
                }
                return false;
            }
        });

        ok.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new SendInfoTask().execute(etPredict.getText().toString()+"Y");
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        SendPredict("http://123.207.114.109:8080/predict",ReceiveData);

                        /**
                         * 延时执行的代码
                         */

                    }
                },3000); // 延时3秒

                //String name = String.valueOf(etSend.getText());
                //String pass = String.valueOf(password.getText());
                //



            }
        });
//        okone.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                String temp = ReceiveData;
//                String url = "http://192.168.43.170:80/predict";//替换成自己的服务器地址
//                SendPredict(url,ReceiveData);
//
//            }
//        });
    }

//    public void sendtofuwuqi()
//    {
//        Toast.makeText(MainActivity.this, ccv.mCurrentProgress, Toast.LENGTH_SHORT).show();
//        new SendInfoTask().execute(ccv.mCurrentProgress+"X");
//                new Handler().postDelayed(new Runnable() {
//                    @Override
//                    public void run() {
//                        SendMessage("http://123.207.114.109:8080/register",ReceiveData);
//
//                        /**
//                         * 延时执行的代码
//
//                         */
//
//                    }
//                },3000); // 延时3秒
//    }




    public void InitBluetooth()
    {
        //得到一个蓝牙适配器
        mBluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
        if(mBluetoothAdapter == null)
        {
            Toast.makeText(this, "你的手机不支持蓝牙", Toast.LENGTH_LONG).show();
            finish();
            return;
        }

    }

    //@Override
//    public boolean onCreateOptionsMenu(Menu menu) {
//        // Inflate the menu; this adds items to the action bar if it is present.
//        getMenuInflater().inflate(R.menu);
//        return true;
//    }

    //连接蓝牙设备的异步任务
    class ConnectTask extends AsyncTask<String,String,String>
    {


        @Override
        protected String doInBackground(String... params) {
            // TODO Auto-generated method stub
            BluetoothDevice device = mBluetoothAdapter.getRemoteDevice(params[0]);

            try {

                btSocket = device.createRfcommSocketToServiceRecord(MY_UUID);


                btSocket.connect();

                Log.e("error", "ON RESUME: BT connection established, data transfer link open.");

            } catch (IOException e) {

                try {
                    btSocket.close();
                    return "Socket 创建失败";

                } catch (IOException e2) {

                    Log .e("error","ON RESUME: Unable to close socket during connection failure", e2);
                    return "Socket 关闭失败";
                }

            }
            //取消搜索
            mBluetoothAdapter.cancelDiscovery();

            try {
                outStream = btSocket.getOutputStream();

            } catch (IOException e) {
                Log.e("error", "ON RESUME: Output stream creation failed.", e);
                return "连接失败";
            }

            imgone.setImageResource(R.drawable.ic_connected);
            return "斗篷已连接";
        }

        @Override    //这个方法是在主线程中运行的，所以可以更新界面
        protected void onPostExecute(String result) {
            // TODO Auto-generated method stub

            //连接成功则启动监听
            rThread=new ReceiveThread();

            rThread.start();

            statusLabel.setText(result);

            super.onPostExecute(result);
        }



    }

    //发送数据到蓝牙设备的异步任务
    class SendInfoTask extends AsyncTask<String,String,String>
    {

        @Override
        protected void onPostExecute(String result) {
            // TODO Auto-generated method stub
            super.onPostExecute(result);

            statusLabel.setText(result);

            //将发送框清空
            //etSend.setText("");
        }

        @Override
        protected String doInBackground(String... arg0) {
            // TODO Auto-generated method stub

            if(btSocket==null)
            {
                return "Have connected";
            }

            if(arg0[0].length()>0)//不是空白串
            {
                //String target=arg0[0];

                byte[] msgBuffer = arg0[0].getBytes();

                try {
                    //  将msgBuffer中的数据写到outStream对象中
                    outStream.write(msgBuffer);

                } catch (IOException e) {
                    Log.e("error", "ON RESUME: Exception during write.", e);
                    imgone.setImageResource(R.drawable.ic_unconnected);
                    return "发送失败";

                }

            }

            return "发送成功";
        }

    }


    //从蓝牙接收信息的线程
    class ReceiveThread extends Thread
    {

        String buffer="";

        @Override
        public void run() {

            while(btSocket!=null )
            {
                //定义一个存储空间buff
                byte[] buff=new byte[1024];
                try {
                    inStream = btSocket.getInputStream();
                    System.out.println("waitting for instream");
                    inStream.read(buff); //读取数据存储在buff数组中
//                        System.out.println("buff receive :"+buff.length);


                    processBuffer(buff,1024);

                    //System.out.println("receive content:"+ReceiveData);
                } catch (IOException e) {

                    e.printStackTrace();
                }
            }
        }

        private void processBuffer(byte[] buff,int size)
        {
            int length=0;
            for(int i=0;i<size;i++)
            {
                if(buff[i]>'\0')
                {
                    length++;
                }
                else
                {
                    break;
                }
            }

//			System.out.println("receive fragment size:"+length);

            byte[] newbuff=new byte[length];  //newbuff字节数组，用于存放真正接收到的数据

            for(int j=0;j<length;j++)
            {
                newbuff[j]=buff[j];
            }

            ReceiveData=ReceiveData+new String(newbuff);

            Log.e("Data",ReceiveData);
//			System.out.println("result :"+ReceiveData);
            Message msg=Message.obtain();
            msg.what=1;
            handler.sendMessage(msg);  //发送消息:系统会自动调用handleMessage( )方法来处理消息

        }

    }






    //更新界面的Handler类
    class MyHandler extends Handler{

        @Override
        public void handleMessage(Message msg) {

            switch(msg.what){
                case 1:
                    if(ReceiveData.length() != 0){
                        strR=ReceiveData.substring(ReceiveData.length()-4);
                    }
                    etReceived.setText(strR);
                    break;
            }
        }
    }

    @Override
    protected void onDestroy() {
        // TODO Auto-generated method stub
        super.onDestroy();

        try {
            if(rThread!=null)
            {

                btSocket.close();
                btSocket=null;

                rThread.join();
            }

            this.finish();

        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (InterruptedException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

    }
    private void SendMessage(String url, final String userName) {
        OkHttpClient client = new OkHttpClient();
        FormBody.Builder formBuilder = new FormBody.Builder();
        //String atest="aaa";
        //formBuilder.add("inttest",atest);
        formBuilder.add("username", userName);
        //formBuilder.add("password", passWord);
        Request request = new Request.Builder().url(url).post(formBuilder.build()).build();
        Call call = client.newCall(request);
        call.enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                Toast.makeText(MainActivity.this, "服务器错误", Toast.LENGTH_SHORT).show();
                            }
                        });
                    }
                });
            }

            @Override
            public void onResponse(Call call, final Response response) throws IOException {
                final String res = response.body().string();
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        if (res.contains("C")) {
                            runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    Toast.makeText(MainActivity.this, res, Toast.LENGTH_SHORT).show();
                                    //setone.setText(res);
                                }
                            });
                        } else {
                            runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    Toast.makeText(MainActivity.this, "成功", Toast.LENGTH_SHORT).show();
                                }
                            });

                        }

                    }
                });
            }
        });

    }
    private void SendPredict(String url,final String userName) {
        OkHttpClient client = new OkHttpClient();
        FormBody.Builder formBuilder = new FormBody.Builder();
//        String atest="aaa";
//        formBuilder.add("inttest",atest);
       formBuilder.add("username", userName);
        //formBuilder.add("password", passWord);
        Request request = new Request.Builder().url(url).post(formBuilder.build()).build();
        Call call = client.newCall(request);
        call.enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                Toast.makeText(MainActivity.this, "服务器错误", Toast.LENGTH_SHORT).show();
                            }
                        });
                    }
                });
            }

            @Override
            public void onResponse(Call call, final Response response) throws IOException {
                final String res = response.body().string();
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
//                        if (res.contains("C")) {
//                            runOnUiThread(new Runnable() {
//                                @Override
//                                public void run() {
//                                    Toast.makeText(MainActivity.this, res, Toast.LENGTH_SHORT).show();
//                                    etPredict.setText(res);
//                                }
//                            });
//                        } else {
//                            runOnUiThread(new Runnable() {
//                                @Override
//                                public void run() {
//                                    Toast.makeText(MainActivity.this, "成功", Toast.LENGTH_SHORT).show();
//                                }
//                            });
//
//                        }
                                runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    Toast.makeText(MainActivity.this, res, Toast.LENGTH_SHORT).show();
                                    etPredict.setText(res);
                                }
                            });

                    }
                });
            }
        });

    }


    private void showToast(Context context, String content) {
        if (toast == null) {
            toast = Toast.makeText(context,
                    content,
                    Toast.LENGTH_SHORT);
        } else {
            toast.setText(content);
        }
        toast.show();
    }

//    @Override
//    public boolean onTouchEvent(MotionEvent event) {
//        //获取触点位置的坐标
//        float x = event.getX();    //获得相对于应用左上角的坐标
//        float y = event.getY();
//        switch (event.getAction()) {
//            case MotionEvent.ACTION_DOWN:                          //当在圆圈上按下触点
//                if (isTouchArc(x, y)) {                          //如果在有效点击范围内
//                    mIsTouchOnArc = true;
//                    updateCurrentAngle(x, y);
//                    return true;
//                }
//                break;
//            case MotionEvent.ACTION_MOVE:               //当触点在移动
//                if (mIsTouchOnArc) {
//                    updateCurrentAngle(x, y);
////                    if (mOnCirqueProgressChangeListener != null)
////                        mOnCirqueProgressChangeListener.onChange(mMinProgress, mMaxProgress,
////                                Integer.parseInt(mText.replace("℃", "")));
//                }
//                break;
//            case MotionEvent.ACTION_UP:                 //触点松开
//                mIsTouchOnArc = false;
//
////                new SendInfoTask().execute("X");
//
//                break;
//        }
//
//        invalidate();           //刷新View
//        return true;
//    }
}
